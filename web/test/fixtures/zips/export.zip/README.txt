Not a DICOM file.
